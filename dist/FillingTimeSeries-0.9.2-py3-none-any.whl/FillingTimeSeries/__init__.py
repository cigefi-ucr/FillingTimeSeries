from FillingTimeSeries.FillingMethods import PrincipalComponentAnalysis, Autoregression, ComponentsAutoregression
#These classes will be available to the user