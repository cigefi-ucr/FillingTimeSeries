from FillingTimeSeries.FillingMethods import AutoRegression, PrincipalComponentAnalysis 
#These classes will be available to the user